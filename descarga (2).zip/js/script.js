// Escribir aqui el código Javascriptdocument.getElementById('jobForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que la página se recargue

    const nombre = document.getElementById('nombre').value.trim();
    const email = document.getElementById('email').value.trim();
    const puesto = document.getElementById('puesto').value;
    const cv = document.getElementById('cv').files[0];
    const mensajeRespuesta = document.getElementById('mensajeRespuesta');

    if (!nombre || !email || !puesto || !cv) {
        mensajeRespuesta.textContent = 'Por favor, completa todos los campos obligatorios.';
        mensajeRespuesta.style.color = '#dc3545';
        return;
    }

    // Simulación de envío exitoso
    mensajeRespuesta.textContent = `¡Muchas gracias, ${nombre}! Tu solicitud para la vacante de "${puesto}" ha sido enviada correctamente.`;
    mensajeRespuesta.className = 'exito';

    // Limpiar el formulario
    document.getElementById('jobForm').reset();
});
document.getElementById('jobForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita que la página se recargue

    const nombre = document.getElementById('nombre').value.trim();
    const email = document.getElementById('email').value.trim();
    const puesto = document.getElementById('puesto').value;
    const cv = document.getElementById('cv').files[0];
    const mensajeRespuesta = document.getElementById('mensajeRespuesta');

    if (!nombre || !email || !puesto || !cv) {
        mensajeRespuesta.textContent = 'Por favor, completa todos los campos obligatorios.';
        mensajeRespuesta.style.color = '#dc3545';
        return;
    }

    // Simulación de envío exitoso
    mensajeRespuesta.textContent = `¡Muchas gracias, ${nombre}! Tu solicitud para la vacante de "${puesto}" ha sido enviada correctamente.`;
    mensajeRespuesta.className = 'exito';

    // Limpiar el formulario
    document.getElementById('jobForm').reset();
});
